# Actividad evaluable Unidades 2 y 3

Desarrollo de una web mediante PHP

por: Álex Soriano Rueda

---

## Vulnerabilidades

He programado solo las funciones que se requieren la actividad. Así que hay vulnerabilidades sin revisar, como por ejemplo:

- La "sesión" del usuario se mantiene pasando el parámetro del nombre por la URL, así que al eliminar una cuenta, se hace utilizando el nombre, y borra cuenta con la que coincida. Sé que esto se puede solucionar pasando el 'id' en vez del nombre, ya que es único para cada usuario, o también, haciendo que el nombre no pueda ser repetido. Iba a serializar el array con los datos del usuario, pero me he dado cuenta de que expone información sensible, como la contraseña, así que esto lo he hecho para la consulta de información de los platos.

- No se utiliza ninguna función para filtrar los datos introducidos, excepto en el e-mail.

- No le he dado estilo a la página de información de los platos, sólo muestro la información que contiene el archivo.

## Algunas funciones:

- Si el correo electrónico ya existe, no dejará registrarlo.

- Muestra si la contraseña es erronea o si el correo no está registrado.

- La función `consultar_usuarios()` devuelve siempre un array con todos los usuarios registrados en el fichero CSV y cada usuario es un array asociativo.

- La función `consultar_platos()` también devuelve un array con todos los platos del fichero CSV y cada plato es un array asociativo. Los platos se consultan mediante el ID con el método GET, en el archivo `procesarconsulta.php`.

- Siempre se le asigna un ID a un nuevo usuario (procesarregistro.php) que corresponde a el órden numérico de la cantidad de usuarios. Los datos del formulario de registro se envían con el método POST.

- Le he añadido algo de estilo a el formulario



