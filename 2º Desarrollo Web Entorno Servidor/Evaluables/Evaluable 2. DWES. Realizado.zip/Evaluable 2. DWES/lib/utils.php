<?php

function consultar_usuarios(){

    $userTemp = array(
        "id" => "",
        "nombre" => "",
        "apellidos" => "",
        "correo" => "",
        "contraseña" => "",
        "teléfono" => "",
        "provincia"=> "",
        "ciudad" => "",
        "codigo_postal" => ""
    );

    $usersDir = '../bbdd/usuarios.csv';
    $user = array();
    $usersDB = array();

    if(($manejador = fopen($usersDir, "r")) !== false) {
        
        // Lee fila a fila
        while(($arrayFila = fgetcsv($manejador, 1000, ",")) !== false){

            // Se guarda cada valor de la fila en la variable $user
            for($i = 0; $i < count($arrayFila); $i++){
                $user[$i] = $arrayFila[$i];
            }

            // Pasa los valores del array $user a $userTemp(array asociativo)
            $i = 0;
            foreach($userTemp as $key => $value){
                $userTemp[$key] = $user[$i];
                $i++;
            }

            // Añade el array $userTemp en $usersDB
            array_push($usersDB, $userTemp);
            
        }
    }

    // Se cierra el archivo
    fclose($manejador);

    return $usersDB;

}

function registrar_usuario($newUser){

    $usuarios = consultar_usuarios();
    $usersDir = '../bbdd/usuarios.csv';
    $registro = true;
    $newId;
    
    for ($i=0; $i < count($usuarios) ; $i++) { 
    
        $user = $usuarios[$i];

        // Comprueba si el correo ya existe. Si existe, no dejará registrarse.
        if($user["correo"] == $newUser["correo"]){
            $registro = false;
            continue;
        }
    }

    if($registro == true){
        // Registrar usuario

        // Añade el nuevo usuario a el array de usuarios.
        array_push($usuarios,$newUser);
        
        $manejador = fopen($usersDir, "w");

        for ($i=0; $i <count($usuarios) ; $i++) { 
            
            fputcsv($manejador, $usuarios[$i], ",");

        }
        fclose($manejador);
    }

    return $registro;
};

function consultar_platos(){

    $platoTemp = array(
        "id" => "",
        "nombre" => "",
        "ingredientePrincipal" => "",
        "alérgeno" => ""
    );

    $platosDir = '../bbdd/platos.csv';
    $plato = array();
    $platosDB = array();

    if(($manejador = fopen($platosDir, "r")) !== false) {
        
        while(($arrayFila = fgetcsv($manejador, 1000, ",")) !== false){

            for($i = 0; $i < count($arrayFila); $i++){
                $plato[$i] = $arrayFila[$i];
            }

            $i = 0;
            foreach($platoTemp as $key => $value){
                $platoTemp[$key] = $plato[$i];
                $i++;
            }

            array_push($platosDB, $platoTemp);
            
        }
    }

    fclose($manejador);

    return $platosDB;

};

function borrar_cuenta($nombre){

    $usuarios = consultar_usuarios();
    $borrar = false;
    
    // Recorre el array de usuarios
    for ($i=0; $i < count($usuarios) ; $i++) { 
    
        $user = $usuarios[$i];

        // Identifica el usuario que hay que borrar por su nombre. 
        if($user["nombre"] == $nombre){
            
            //Elimina el elemento del array de usuarios.
            unset($usuarios[$i]);
            $borrar = true;

            continue;
        }
    }

    // Una vez eliminado el usuario del array, se reescribe el fichero CSV.
    if($borrar){

        $usersDir = '../bbdd/usuarios.csv';
        $manejador = fopen($usersDir, "w");

        for ($i=0; $i <= count($usuarios) ; $i++){

            // Si el elemento está vacío, se añade el siguiente.
            if($usuarios[$i] ==! null){
                fputcsv($manejador, $usuarios[$i], ",");
            }else{
                // Si el elemento vacío es el último, no se añade nada.
                if($i == count($usuarios)){
                    break;
                }
                fputcsv($manejador, $usuarios[$i+1], ",");
                $i++;
            }
        }

        fclose($manejador);
    }

    return $borrar;

};

?>
