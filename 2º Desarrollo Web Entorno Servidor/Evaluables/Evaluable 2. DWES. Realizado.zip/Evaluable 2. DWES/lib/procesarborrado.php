<?php

require('utils.php');

$nombre = $_GET['nombre'];

if(borrar_cuenta($nombre)){
    header("Location:../index.html");
}else{
    echo "Algo ha ido mal, no se ha podido borrar la cuenta.";
};