<?php

require("utils.php");

$usuarios = consultar_usuarios();

$newId = count($usuarios) + 1; // Saca el ID que le corresponde a el nuevo usuario.

$newUser = array(
    "id" => $newId,
    "nombre" => $_POST['nombre'],
    "apellidos" => $_POST['apellidos'],
    "correo" => $_POST['correo'],
    "contraseña" => $_POST['contraseña'],
    "teléfono" => $_POST['telefono'],
    "provincia"=> $_POST['provincia'],
    "ciudad" => $_POST['ciudad'],
    "codigo_postal" => $_POST['codigo_postal'],
);

if(registrar_usuario($newUser)) {
    header("location:../platos.php?nombre=" . $_POST['nombre']);
}else{
    echo "No se ha podido registrar el usuario.";
};

?>