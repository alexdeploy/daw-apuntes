<?php

require("utils.php");

$platos = consultar_platos();

$idPlato = $_GET["id"];

for ($i=0; $i < count($platos); $i++) {

    $plato = $platos[$i];

    if($plato["id"] == $idPlato){
        header("location:../ficha_plato.php?plato=" . serialize($plato));
    }
}

?>