<?php

require("utils.php");

$login = false;
$res = "";

$email = $_POST['email'];
$password = $_POST['password'];

$usuarios = consultar_usuarios();

// Recorre el array con todos los usuarios
for ($i=0; $i < count($usuarios); $i++) {

    // Guarda el usuario en la variable $user como un array asociativo
    $user = $usuarios[$i];

    // Comprueba si el correo y la contraseña coinciden.
    if($user["correo"] == $email){
        if ($user["contraseña"] == $password) {
            header("location:../platos.php?nombre=" . $user['nombre']);
        }else{
            $res = "Contraseña incorrecta";
            break; // Cuando encuentra el correo pero la contraseña es erronea, sale del bucle.
        }
    }else {
        $res = "El correo $email no está registrado.";
    }
}

echo "$res";

?>