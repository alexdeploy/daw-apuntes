<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <title>🍴 platos | happy fork 🍴</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/estilos.css">
    
</head>

<body>
    
    <div class="alert alert-secondary d-flex">
        <?php
        $nombre = $_GET['nombre'];
        echo "<h1> Hola $nombre, bienvenido a happy fork&nbsp</h1>";
        echo "<a class='btn btn-dark' href='./borrarcuenta.php?nombre=" . $_GET['nombre'] . "'>Eliminar cuenta</a>&nbsp;&nbsp;"
        ?>
    </div>

    <div class="container">
        <div class="row">

        <a class="custom-card" href="lib\procesarconsulta.php?id=1" target="blank">
            <div class="card" style="width: 15rem; height: 30rem">
                <img src="imgs\platos\1.jpg" class="card-img-top">
                <div class="card-body">
                    <p class="card-text">Patatas con alioli</p>
                </div>
            </div>
        </a>
        
            <a  class="custom-card" href="lib\procesarconsulta.php?id=4" target="blank">
                <div class="card" style="width: 15rem; height: 30rem ">
                    <img src="imgs\platos\2.jpg" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text">Tallarines con cerdo</p>
                    </div>
                </div>
            </a>
        
            <a  class="custom-card" href="lib\procesarconsulta.php?id=3" target="blank">
                <div class="card" style="width: 15rem; height: 30rem">
                    <img src="imgs\platos\3.jpg" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text">Macarrones con atún</p>
                    </div>
                </div>
            </a>

            <a  class="custom-card" href="lib\procesarconsulta.php?id=2" target="blank">
                <div class="card" style="width: 15rem; height: 30rem">
                    <img src="imgs\platos\4.jpg" class="card-img-top">
                    <div class="card-body">
                        <p class="card-text">Hamburguesa de seitán</p>
                    </div>
                </div>
            </a>
        </div>
    </div>
</body>

</html>
