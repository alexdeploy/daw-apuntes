package ud9_e7_figuras;

public interface iFigura2D {
    
    // Declaración de métodos sin implementación
    double perimetro();
    double area();
    void escalar(double escala);
    void imprimir();
    
}
